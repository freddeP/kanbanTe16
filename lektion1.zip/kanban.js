
// lägg till klickkkkk på save-knappen


const mySaveButton = document.getElementById("saveNewTask");

mySaveButton.addEventListener("click",saveNewTask);


function saveNewTask(){

    alert("Hej TE16");


}






